# minium小程序测试框架

## 开发
1. 更新测试报告
    构件完成之后，替换minium/framework/dist里面的文件
2. 安装: `python3 setup.py install`
2. 生成安装包: `python3 setup.py sdist --formats=gztar,zip`


## 设计

架构
![](./arch.png)

单机方案
![](./minium.png)

多机方案
![](./multi-session.png)


